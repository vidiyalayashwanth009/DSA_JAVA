class Node 
{
    int data;
    Node prev;
    Node next;
    Node(int data)
    {
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}
public class DoublyLinkedList
{
    Node Head;
    DoublyLinkedList()
    {
        this.Head = null;
    }
    public void Insert_At_End(int data)
    {
        Node newnode = new Node(data);
        if(this.Head==null)
        {
            this.Head = newnode;
        }
        else
        {
            Node temp = this.Head;
            while(temp.next!=null)
            {
                temp = temp.next;
            }
            temp.next = newnode;
            newnode.prev = temp;
        }
    }
    public void Insert_At_Begin(int data)
	{
		Node newnode = new Node(data);
		if(this.Head==null)
		{
			this.Head=newnode;
		}
		else
		{
			newnode.next = this.Head;
		    this.Head.prev = newnode;
			this.Head = newnode;
		}
	}
	public void Insert_At_Position(int data, int pos)
	{
		Node newnode = new Node(data);
		if(pos==1)
		{
			newnode.next = this.Head;
			this.Head.prev = newnode;
			this.Head = newnode;
		}
		else
		{
			Node temp = this.Head;
			while(pos-2>0 && temp.next!=null)
			{
				temp = temp.next;
				pos--;
			}
			newnode.prev = temp;
			newnode.next = temp.next;
			if(temp.next != null)
			   temp.next.prev = newnode;
			temp.next = newnode;
		}
	}
	public void Delete_At_End()
	{
	    if (this.Head==null)
	    {
	        System.out.println("List is Empty");
	    }
	    else if (this.Head.next == null)
	    {
	        this.Head = null;
	    }
	    else
	    {
	        Node temp = this.Head;
	        while(temp.next.next != null)
	        {
	            temp = temp.next;
	        }
	        temp.prev.next = null;
	    }
	}
	public void Delete_At_Begin()
	{
	    if (this.Head==null)
	    {
	        System.out.println("List is Empty");
	    }
	    else if(this.Head.next == null)
	    {
	        this.Head = null;
	    }
	    else
	    {
	        this.Head = this.Head.next;
	        this.Head.prev = null;
	    }
	}
	public void Delete_At_Position(int pos)
	{
	    if(pos == 1)
	    {
	        this.Head = this.Head.next;
	        this.Head.prev = null;
	    }
	    else
	    {
	        Node temp = this.Head;
	        while(pos-2 > 0 && temp.next!=null)
	        {
	            temp = temp.next;
	            pos--;
	        }
	        temp.next = temp.next.next;
	        if(temp.next!=null)
	           temp.next.prev = temp;
	    }
	}
	public void Display()
	{
		Node temp = this.Head;
		System.out.println(this.Head);
		while(temp!=null)
		{
			System.out.println(temp.prev+" "+temp.data+" "+temp.next);
			temp = temp.next;
		}
	}
	public static void main (String[] args)
	{
		DoublyLinkedList dil = new DoublyLinkedList();
		dil.Insert_At_End(4);
		dil.Insert_At_End(5);
		dil.Insert_At_End(6);
		dil.Insert_At_End(7);
		
	    dil.Insert_At_Begin(4);
		dil.Insert_At_Begin(3);
		dil.Insert_At_Begin(2);
		dil.Insert_At_Begin(1);
		dil.Display();
		System.out.println();
		
		dil.Insert_At_Position(2,5);
		dil.Display();
		System.out.println();
		
		dil.Delete_At_End();
		dil.Display();
		System.out.println();
		
		dil.Delete_At_Begin();
		dil.Display();
		System.out.println();
		
		dil.Delete_At_Position(1);
		dil.Display();
		System.out.println();
	}
}   
    
    
    
    