class Node
{
    int data ;
    Node data;
    Node (int data)
    {
        this.data = data;
        this.next = null;
    }
}
public class STACK
{
    Node Stack;
    int SIZE = 3;
    int count = 0;
    STACK()
    {
        this.Stack = null;
    }
    public void PUSH(int data)
    {
        if(this.IsFull())
        {
            System.out.println("Stack OverFlow");
        }
        else
        {
            Node newnode = new node(data);
            newnode.next = this.Stack;
            this.Stack = newnode;
            count++;
            System.out.println(data+" got PUSHED into stack");
        }
    }
    public void POP()
    {
        if(this.IsEmpty())
        {
            System.out.println("Stack Underflow");
        }
        else
        {
            System.out.println(this.Stack.data+" POPPED from Stack ");
            this.Stack = this.Stack.next;
            count--;
        }
    }
    public void PEEK()
    {
        if(this.IsEmpty())
        {
            System.out.println("Stack is emptu");
        }
        else
        {
            System.out.println("The ");
        }
        
    }
    public static void main(String[] args)
    {
        STACK stk = new STACK();
    }
}
