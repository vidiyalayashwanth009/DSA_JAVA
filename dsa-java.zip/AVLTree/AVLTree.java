import java.util.*;
class Node 
{
    int data, height;
    Node left, right;

    Node(int data) 
    {
        this.data = data;
        this.height = 1;
        this.left = null ;
        this.right = null;
    }
}
public class AVLTree 
{
    Node root;
    int height(Node N) 
    {
        if (N == null)
            return 0;
        return N.height;
    }
    
    Node rightRotate(Node y) 
    {
        Node x = y.left;
        Node z = x.right;

        x.right = y;
        y.left = z;

        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        return x;
    }
    Node leftRotate(Node x) 
    {
        Node y = x.right;
        Node z = y.left;

        y.left = x;
        x.right = z;

        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;

        return y;
    }
    int getBalance(Node N) 
    {
        if (N == null)
            return 0;
        return height(N.left) - height(N.right);
    }
    Node insert(Node node, int data) 
    {
        if (node == null)
            return (new Node(data));

        if (data < node.data)
            node.left = insert(node.left, data);
        else if (data > node.data)
            node.right = insert(node.right, data);
        else
            return node;

        node.height = 1 + Math.max(height(node.left), height(node.right));

        int balance = getBalance(node);

        if (balance > 1 && data < node.left.data)
            return rightRotate(node);

        if (balance < -1 && data > node.right.data)
            return leftRotate(node);

        if (balance > 1 && data > node.left.data) 
        {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        if (balance < -1 && data < node.right.data) 
        {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }

        return node;
    }
    Node minValueNode(Node node) 
    {
        Node current = node;
        while (current.left != null)
            current = current.left;

        return current;
    }
    Node deleteNode(Node root, int data) 
    {
        if (root == null)
            return root;

        if (data < root.data)
            root.left = deleteNode(root.left, data);
        else if (data > root.data)
            root.right = deleteNode(root.right, data);
        else 
        {
            if ((root.left == null) || (root.right == null)) 
            {
                Node temp = (root.left != null) ? root.left : root.right;

                if (temp == null) 
                {
                    temp = root;
                    root = null;
                } 
                else
                    root = temp;
            } 
            else 
            {
                Node temp = minValueNode(root.right);

                root.data = temp.data;

                root.right = deleteNode(root.right, temp.data);
            }
        }
        if (root == null)
            return root;

        root.height = Math.max(height(root.left), height(root.right)) + 1;

        int balance = getBalance(root);

        if (balance > 1 && getBalance(root.left) >= 0)
            return rightRotate(root);

        if (balance > 1 && getBalance(root.left) < 0) 
        {
            root.left = leftRotate(root.left);
            return rightRotate(root);
        }

        if (balance < -1 && getBalance(root.right) <= 0)
            return leftRotate(root);

        if (balance < -1 && getBalance(root.right) > 0) 
        {
            root.right = rightRotate(root.right);
            return leftRotate(root);
        }

        return root;
    }
    void preOrder(Node node) 
    {
        if (node != null) 
        {
            System.out.print(node.data + " ");
            preOrder(node.left);
            preOrder(node.right);
        }
    }
    public static void main(String[] args) 
    {
        AVLTree tree = new AVLTree();
        Scanner sc = new Scanner(System.in);
        int input = sc.nextInt();
        while(input!=-1)
        {
            tree.root = tree.insert(tree.root, input);
            input = sc.nextInt();
        }
        // tree.root = tree.insert(tree.root, 2);
        // tree.root = tree.insert(tree.root, 1);
        // tree.root = tree.insert(tree.root, 7);
        // tree.root = tree.insert(tree.root, 4);
        // tree.root = tree.insert(tree.root, 5);
        // tree.root = tree.insert(tree.root, 3);
        // tree.root = tree.insert(tree.root, 8);
        tree.preOrder(tree.root);
        // tree.Inorder
        // tree.preOrder(tree.root);
    }
}