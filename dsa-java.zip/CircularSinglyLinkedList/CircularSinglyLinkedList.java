import java.util.* ;
class Node 
{
    int data;
    Node next;
    Node(int data)
    {
        this.data = data;
        this.next = null;
    }
}
public class CircularSinglyLinkedList
{
    Node Head ;
    Node Tail ;
    CircularSinglyLinkedList()
    {
        this.Head = null;
        this.Tail = null;
    }
    public void Insert_At_End(int data)
    {
        Node newnode = new Node(data);
        if(this.Head==null && this.Tail == null)
        {
            this.Head = newnode;
            this.Tail = newnode;
        }
        else 
        {
            this.Tail.next = newnode;
            this.Tail = newnode;
        }
        this.Tail.next = this.Head;
    }
    public void Insert_At_Begin(int data)
    {
        Node newnode = new Node(data);
        if(this.Head==null && this.Tail == null)
        {
            this.Head = newnode;
            this.Tail = newnode;
        }
        else 
        {
            newnode.next = this.Head;
            this.Head = newnode;
        }
        this.Tail.next = this.Head;
    }
    public void Insert_At_Position(int data, int pos)
    {
        Node newnode = new Node(data);
        if (pos==1)
        {
            newnode.next = this.Head;
            this.Head = newnode;
            this.Tail.next = this.Head;
        }
        else
        {
            Node temp = this.Head ;
            while(pos-2 > 0 && temp.next!=this.Head)
            {
                temp = temp.next ;
                pos--;
            }
            newnode.next = temp.next;
            temp.next = newnode ;
            
        }
    }
    public void Delete_At_End()
    {
        if (this.Head == null && this.Tail==null)
        {
            System.out.println("List is Empty");
        }
        else if (this.Head.next == null)
        {
            this.Head = null;
            this.Tail = null;
        }
        else 
        {
            Node temp = this.Head;
            while(temp.next!=this.Tail)
            {
                temp =temp.next;
            }
            this.Tail = temp;
            this.Tail.next = this.Head;
        }
    }
    public void Delete_At_Begin()
    {
        if (this.Head == null && this.Tail==null)
        {
            System.out.println("List is Empty");
        }
        else if (this.Head.next == null)
        {
            this.Head = null;
            this.Tail = null;
        }
        else 
        {
            this.Head = this.Head.next ;
            this.Tail.next = this.Head ;
        }
    }
    public void Delete_At_Position(int pos)
    {
        if (this.Head == null && this.Tail==null)
        {
            System.out.println("List is Empty");
        }
        else if (pos==1)
        {
            this.Head = this.Head.next ;
            this.Tail.next = this.Head;
        }
        else 
        {
            Node temp = this.Head ;
            while(pos-2 > 0 && temp.next!=this.Head)
            {
                temp = temp.next ;
                pos--;
            }
            if (temp.next != null)
                temp.next = temp.next.next;
            
        }
    }
    public void Display()
    {
        Node temp = this.Head;
        System.out.println(this.Head);
        while(temp.next!=this.Head)
        {
            System.out.println(temp+" "+temp.data+" "+temp.next);
            temp = temp.next;
        }
        System.out.println(temp+" "+temp.data+" "+temp.next);
    }
	public static void main(String[] args)
	{
		CircularSinglyLinkedList sll = new CircularSinglyLinkedList();
		Scanner sc = new Scanner(System.in);

		System.out.println("**************** WELCOME ****************");
		System.out.println("Enter 1 to Insert Element at End.  ");
		System.out.println("Enter 2 to Insert Element at Begining. ");
		System.out.println("Enter 3 to Insert Element at Position. ");
		System.out.println("Enter 4 to Delete Element at End. ");
		System.out.println("Enter 5 to Delete Element at Begining. ");
		System.out.println("Enter 6 to Delete Element at Position. ");
		System.out.println("Enter 7 to Display the LinledList. ");
		System.out.println("Enter -1 to EXIT. ");

		int data, ip, pos ;

		while(true)
		{
			System.out.print("Enter Input :- ");
			ip = sc.nextInt();
			
			if (ip == 1)
			{
				System.out.print("Enter value to Insert at End :- ");
				data = sc.nextInt();
				sll.Insert_At_End(data);
				System.out.println(data+" Inserted at End");
			}
			else if (ip == 2)
			{
				System.out.print("Enter value to Insert at Begining :- ");
				data = sc.nextInt();
				sll.Insert_At_Begin(data);
				System.out.println(data+" Inserted at Begining");
			}
			else if (ip == 3)
			{
				System.out.print("Enter value and Position to Insert :- ");
				data = sc.nextInt();
				pos = sc.nextInt();
				sll.Insert_At_Position(data, pos);
				System.out.println(data+" Inserted at "+pos+" Position");
			}
			else if (ip == 4)
			{
				sll.Delete_At_End();
				System.out.println("value Deleted at End");
			}
			else if (ip == 5)
			{
				sll.Delete_At_Begin();
				System.out.println("value Deleted at Begin");
			}
			else if (ip == 6)
			{
				System.out.print("Enter Position to Delete :- ");
				pos = sc.nextInt();
				sll.Delete_At_Position(pos);
				System.out.println("value Deleted at "+pos+" Position");
			}
			else if (ip == 7)
			{
			    System.out.println("The LinkedList is --- ");
				sll.Display();
			}
			else if (ip == -1)
			{
				System.out.println("Program EXIT");
				break;
			}
			
		}
	}
}